/* obey.c - Obey Your Simian Overlords
   Copyright (C) 2004 Sean Ridenour.
   Like anybody would ever want to copy this nonsense.
*/

#include <stdio.h>
#include <stdlib.h>

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>

typedef void (*GL_ActiveTextureARB_func)(GLuint);
typedef void (*GL_MultiTexCoord2fARB_func)(GLuint, GLfloat, GLfloat);

GL_ActiveTextureARB_func glActiveTextureARB_ptr = NULL;
GL_MultiTexCoord2fARB_func glMultiTexCoord2fARB_ptr = NULL;

struct {
	GLfloat x, y, z;
} view;

/* texture objects */
GLuint monkey;
GLuint monkey_eyes;
GLuint obey;

/* display lists */
GLuint monkey_list;
GLuint obey_list;

static float z_rot = 0.0;
static float z_move = 0.0;
static float z_direction = 0.05f;

static float eye_color = 1.0f;
static float eye_color_shift = 0.05f;

static int delay_length = 20;				/* about 50fps */

static char obey_long[] = { "Obey Your Simian Overlords" };
static char obey_short[] = { "Obey" };

static int load_texture(char *filename, int t)
{
	SDL_Surface *tex = NULL;

	tex = IMG_Load(filename);
	if (tex == NULL) {
		fprintf(stderr, "error: IMG_Load() failed\n");
		return -1;
	}

	/* We shouldn't need to lock it, but whatever */
	if (SDL_MUSTLOCK(tex))
		SDL_LockSurface(tex);

	switch(t) {
	case 0:		/* monkey face */
		glActiveTextureARB_ptr(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glGenTextures(1, &monkey);
		glBindTexture(GL_TEXTURE_2D, monkey);
		break;
	case 1:		/* "OBEY" text */
		glActiveTextureARB_ptr(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glGenTextures(1, &obey);
		glBindTexture(GL_TEXTURE_2D, obey);
		break;
	case 2:		/* Brightness map for monkey eyes */
		glActiveTextureARB_ptr(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glGenTextures(1, &monkey_eyes);
		glBindTexture(GL_TEXTURE_2D, monkey_eyes);
		break;
	}

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	if(t != 2)
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	else
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	if (tex->format->BytesPerPixel == 4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tex->w, tex->h, 0,
			     GL_RGBA, GL_UNSIGNED_BYTE, tex->pixels);
	else
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tex->w, tex->h, 0,
			     GL_RGB, GL_UNSIGNED_BYTE, tex->pixels);

	if (SDL_MUSTLOCK(tex))
		SDL_UnlockSurface(tex);

	SDL_FreeSurface(tex);

	if(glGetError())
		return -1;

	return 0;
}

static void init_gl(int w, int h)
{
	glViewport(0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90.0, (GLfloat) w / (GLfloat) h, 0.0, 30.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);

	glEnable(GL_TEXTURE_2D);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	view.x = 0.0;
	view.y = 0.0;
	view.z = -3.0;

	/* Set up multitexturing */
	glActiveTextureARB_ptr = (GL_ActiveTextureARB_func)
			SDL_GL_GetProcAddress("glActiveTextureARB");

	glMultiTexCoord2fARB_ptr = (GL_MultiTexCoord2fARB_func)
			SDL_GL_GetProcAddress("glMultiTexCoord2fARB");

	if((glActiveTextureARB_ptr == NULL) ||
	   (glMultiTexCoord2fARB_ptr == NULL)) {
		fprintf(stderr,"error: multitexturing not supported\n");
		exit(1);
	}

	monkey_list = glGenLists(1);
	glNewList(monkey_list, GL_COMPILE);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0, 1.0);
			glVertex3f(-1.0, -1.0, 0.0);
			glTexCoord2f(1.0, 1.0);
			glVertex3f(1.0, -1.0, 0.0);
			glTexCoord2f(1.0, 0.0);
			glVertex3f(1.0, 1.0, 0.0);
			glTexCoord2f(0.0, 0.0);
			glVertex3f(-1.0, 1.0, 0.0);
		glEnd();
	glEndList();

	obey_list = glGenLists(1);
	glNewList(obey_list, GL_COMPILE);
		glLoadIdentity();

		glTranslatef(view.x, view.y, view.z);

		glBegin(GL_QUADS);
			glTexCoord2f(0.0, 1.0);
			glVertex3f(-2.0, -3.0, 0.0);
			glTexCoord2f(1.0, 1.0);
			glVertex3f(2.0, -3.0, 0.0);
			glTexCoord2f(1.0, 0.0);
			glVertex3f(2.0, -1.0, 0.0);
			glTexCoord2f(0.0, 0.0);
			glVertex3f(-2.0, -1.0, 0.0);
		glEnd();
	glEndList();

	if(glGetError()) {
		fprintf(stderr,"error: OpenGL error in init_gl()\n");
		exit(1);
	}
}

static void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);

	glLoadIdentity();

	glTranslatef(view.x, view.y, view.z + z_move);
	glRotatef(z_rot, 0.0, 0.0, 1.0);

	glActiveTextureARB_ptr(GL_TEXTURE1_ARB);
	glDisable(GL_TEXTURE_2D);

	glActiveTextureARB_ptr(GL_TEXTURE0_ARB);
	glBindTexture(GL_TEXTURE_2D, monkey);
	glCallList(monkey_list);
	glDisable(GL_TEXTURE_2D);

	glBlendFunc(GL_SRC_COLOR, GL_ONE_MINUS_SRC_COLOR);
	glColor4f(eye_color, 0.0, 0.0, 1.0);
	glActiveTextureARB_ptr(GL_TEXTURE1_ARB);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, monkey_eyes);
	glBegin(GL_QUADS);
		glMultiTexCoord2fARB_ptr(GL_TEXTURE1_ARB, 0.0, 1.0);
		glVertex3f(-1.0, -1.0, 0.0);
		glMultiTexCoord2fARB_ptr(GL_TEXTURE1_ARB, 1.0, 1.0);
		glVertex3f(1.0, -1.0, 0.0);
		glMultiTexCoord2fARB_ptr(GL_TEXTURE1_ARB, 1.0, 0.0);
		glVertex3f(1.0, 1.0, 0.0);
		glMultiTexCoord2fARB_ptr(GL_TEXTURE1_ARB, 0.0, 0.0);
		glVertex3f(-1.0, 1.0, 0.0);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glActiveTextureARB_ptr(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, obey);
	glCallList(obey_list);

	SDL_GL_SwapBuffers();
}

int main(int argc, char **argv)
{
	SDL_Surface *screen;
	SDL_Event event;
	long start_time, end_time, the_time;
	long frames = 0;
	int w = 800;
	int h = 600;
	int quit = 0;
	float fps;

	if (SDL_Init(SDL_INIT_VIDEO)) {
		fprintf(stderr, "error: %s\n", SDL_GetError());
		exit(1);
	}

	atexit(SDL_Quit);

	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

	screen = SDL_SetVideoMode(w, h, 32, SDL_OPENGL);
	if (screen == NULL) {
		fprintf(stderr, "error: can't set video mode: %s\n",
			SDL_GetError());
		exit(1);
	}

	SDL_WM_SetCaption(obey_long, obey_short);

	init_gl(w, h);

	if (load_texture("monkey.png", 0)) {
		fprintf(stderr, "error: can't load monkey.png: %s\n",
			SDL_GetError());
		exit(1);
	}

	if (load_texture("obey.png", 1)) {
		fprintf(stderr, "error: can't load obey.png: %s\n",
			SDL_GetError());
		exit(1);
	}

	if (load_texture("monkey_eyes.png", 2)) {
		fprintf(stderr, "error: can't load monkey_eyes.png: %s\n",
			SDL_GetError());
		exit(1);
	}

	start_time = SDL_GetTicks();
	while (!quit) {
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT:
				quit = 1;
				break;
			case SDL_KEYDOWN:
				quit = 1;
				break;
			default:
				break;
			}
		}

		display();

		z_rot += 5.0;
		if (z_rot >= 360.0)
			z_rot = 0.0;

		z_move += z_direction;

		if ((z_move + view.z) >= -0.5)
			z_direction = -z_direction;

		if ((z_move + view.z) <= view.z)
			z_direction = -z_direction;

		eye_color += eye_color_shift;
		/* We let it go past 1.0 so that the eyes stay full red longer,
		   since OpenGL clips it to 1.0 */
		if(eye_color >= 1.2)
			eye_color_shift = -eye_color_shift;

		if(eye_color <= 0.0)
			eye_color_shift = -eye_color_shift;

		if(argc == 1)
			SDL_Delay(delay_length);

		frames++;
	}
	end_time = SDL_GetTicks();
	the_time = end_time - start_time;

	fps = (float) frames / ((float) the_time / 1000.0f);

	if(argc > 1) {
		printf("Total running time: %.02f seconds\n",
			(float)the_time / 1000.0f);
		printf("Average frames per second: %.02f\n", fps);
	}

	return 0;
}

